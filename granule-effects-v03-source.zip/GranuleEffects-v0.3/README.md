# Granule Effects v0.3

Native Windows window-effects utility.

## Motion
- release-only wobble
- minimize-to-taskbar ghost animation
- restore-from-taskbar curved pop animation
- animation speed and wobble strength controls

## Appearance
- rounded corners
- Granule violet DWM border

## Utilities
- always-on-top hotkey: Ctrl+Alt+T
- center active window: Ctrl+Alt+C
- test wobble: Ctrl+Alt+W
- optional start with Windows
- skip fullscreen windows

## Safety
- panic: Ctrl+Alt+G
- close button fully exits
- settings saved under `%APPDATA%\\Granule\\effects.ini`

The taskbar animation is a visual overlay. Windows does not expose arbitrary cross-process `AnimateWindow` control, so Granule captures a temporary visual copy and animates that instead.
