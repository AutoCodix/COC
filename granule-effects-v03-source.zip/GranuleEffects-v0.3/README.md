# Granule Effects v0.3

Native Windows window-motion customizer.

## New in v0.3
- Fully custom dark Granule UI with sidebar, cards, custom toggles and sliders
- Release-only wobble with velocity-aware spring motion
- Taskbar lift animation for restored windows
- Float-in animation for newly opened windows
- Animated minimize hotkey: Ctrl+Alt+M
- Rounded corners and Granule accent border
- Pause effects in fullscreen apps/games
- Start with Windows toggle
- Saved settings under %APPDATA%\GranuleEffects\settings.ini
- X exits completely and restores temporary style tweaks

## Hotkeys
- Ctrl+Alt+G - toggle release wobble
- Ctrl+Alt+T - toggle active window always-on-top
- Ctrl+Alt+C - center active window
- Ctrl+Alt+W - test wobble
- Ctrl+Alt+M - animated minimize active window

Note: native minimize buttons are owned by each application/Windows DWM, so v0.3 does not inject code into other apps to replace every title-bar minimize animation. Restores and new-window float-ins are handled globally without injection.
