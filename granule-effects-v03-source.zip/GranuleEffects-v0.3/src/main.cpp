#define UNICODE
#define _UNICODE
#include <windows.h>
#include <dwmapi.h>
#include <commctrl.h>
#include <shellapi.h>
#include <gdiplus.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cmath>
#include <atomic>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "shell32.lib")

using namespace Gdiplus;

static const wchar_t* CLS = L"GranuleEffectsV03";
static constexpr UINT TICK = 1;
static constexpr UINT SCAN = 2;

struct RectF2 { float x,y,w,h; bool hit(int px,int py) const { return px>=x && py>=y && px<x+w && py<y+h; } };

struct Settings {
    bool releaseWobble = true;
    bool taskbarLift = true;
    bool launchFloat = true;
    bool roundedCorners = true;
    bool accentBorder = false;
    bool pauseFullscreen = true;
    bool startWithWindows = false;
    int strength = 46;
    int bounce = 58;
    int settle = 62;
    int duration = 38;
    int liftSpeed = 56;
    int liftDistance = 72;
};

struct WobbleState {
    HWND hwnd{};
    RECT finalRect{}, lastRect{};
    bool moving=false, animating=false, haveLast=false;
    double dragVX=0, dragVY=0, vx=0, vy=0, ox=0, oy=0;
    ULONGLONG lastTick=0, startTick=0;
};

struct LiftAnim {
    HWND hwnd{};
    RECT finalRect{};
    double x=0,y=0,vx=0,vy=0;
    ULONGLONG startTick=0;
    bool active=false;
};

struct SeenState { bool iconic=false; bool visible=false; };

struct UiState {
    int page=0;
    int hot=0;
    int down=0;
    int draggingSlider=0;
    int mouseX=0,mouseY=0;
    float previewPhase=0.f;
};

static Settings g;
static WobbleState wob;
static LiftAnim lift;
static UiState ui;
static HWND mainWnd=nullptr;
static HWINEVENTHOOK hookStart=nullptr, hookEnd=nullptr, hookLoc=nullptr, hookShow=nullptr;
static std::unordered_map<HWND, SeenState> seen;
static std::atomic<bool> quitting{false};
static ULONG_PTR gdipToken=0;
static HFONT dummyFont=nullptr;

static const Color BG(255, 12, 13, 18);
static const Color SIDEBAR(255, 16, 17, 23);
static const Color CARD(255, 24, 25, 33);
static const Color CARD2(255, 29, 30, 40);
static const Color BORDER(255, 43, 44, 57);
static const Color TEXT(255, 240, 241, 246);
static const Color MUTED(255, 147, 150, 166);
static const Color PURPLE(255, 119, 0, 255);
static const Color PURPLE2(255, 157, 74, 255);
static const Color GREEN(255, 76, 221, 151);

static std::wstring AppDataDir(){
    wchar_t buf[MAX_PATH]{};
    DWORD n=GetEnvironmentVariableW(L"APPDATA",buf,MAX_PATH);
    if(!n||n>=MAX_PATH) return L".";
    std::wstring d=std::wstring(buf)+L"\\GranuleEffects";
    CreateDirectoryW(d.c_str(),nullptr);
    return d;
}
static std::wstring IniPath(){ return AppDataDir()+L"\\settings.ini"; }
static void Save(){
    auto wr=[&](const wchar_t*k,int v){ wchar_t b[32]; _itow_s(v,b,10); WritePrivateProfileStringW(L"Granule",k,b,IniPath().c_str()); };
    wr(L"releaseWobble",g.releaseWobble); wr(L"taskbarLift",g.taskbarLift); wr(L"launchFloat",g.launchFloat);
    wr(L"roundedCorners",g.roundedCorners); wr(L"accentBorder",g.accentBorder); wr(L"pauseFullscreen",g.pauseFullscreen);
    wr(L"startWithWindows",g.startWithWindows); wr(L"strength",g.strength); wr(L"bounce",g.bounce); wr(L"settle",g.settle);
    wr(L"duration",g.duration); wr(L"liftSpeed",g.liftSpeed); wr(L"liftDistance",g.liftDistance);
}
static void Load(){
    auto rd=[&](const wchar_t*k,int def){ return GetPrivateProfileIntW(L"Granule",k,def,IniPath().c_str()); };
    g.releaseWobble=rd(L"releaseWobble",1)!=0; g.taskbarLift=rd(L"taskbarLift",1)!=0; g.launchFloat=rd(L"launchFloat",1)!=0;
    g.roundedCorners=rd(L"roundedCorners",1)!=0; g.accentBorder=rd(L"accentBorder",0)!=0; g.pauseFullscreen=rd(L"pauseFullscreen",1)!=0;
    g.startWithWindows=rd(L"startWithWindows",0)!=0; g.strength=rd(L"strength",46); g.bounce=rd(L"bounce",58); g.settle=rd(L"settle",62);
    g.duration=rd(L"duration",38); g.liftSpeed=rd(L"liftSpeed",56); g.liftDistance=rd(L"liftDistance",72);
}

static bool ShellClass(HWND h){ wchar_t c[96]{}; GetClassNameW(h,c,95); return !wcscmp(c,L"Progman")||!wcscmp(c,L"WorkerW")||!wcscmp(c,L"Shell_TrayWnd")||!wcscmp(c,L"Shell_SecondaryTrayWnd"); }
static bool Eligible(HWND h,bool allowIconic=false){
    if(!h||h==mainWnd||!IsWindow(h)||!IsWindowVisible(h)||ShellClass(h)||GetWindow(h,GW_OWNER)) return false;
    LONG_PTR st=GetWindowLongPtrW(h,GWL_STYLE); if(!(st&WS_CAPTION)) return false;
    if(IsZoomed(h)) return false; if(!allowIconic && IsIconic(h)) return false;
    return true;
}
static bool Fullscreen(HWND h){
    if(!h||!IsWindow(h)) return false; RECT r{}; if(!GetWindowRect(h,&r))return false;
    HMONITOR m=MonitorFromWindow(h,MONITOR_DEFAULTTONEAREST); MONITORINFO mi{sizeof(mi)}; if(!GetMonitorInfoW(m,&mi))return false;
    return r.left<=mi.rcMonitor.left && r.top<=mi.rcMonitor.top && r.right>=mi.rcMonitor.right && r.bottom>=mi.rcMonitor.bottom;
}
static bool EffectsAllowed(HWND h){ return !(g.pauseFullscreen && Fullscreen(h)); }

static void ResetWobble(bool restore){
    if(restore && wob.animating && wob.hwnd && IsWindow(wob.hwnd))
        SetWindowPos(wob.hwnd,nullptr,wob.finalRect.left,wob.finalRect.top,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
    wob={};
}
static void BeginMove(HWND h){
    if(!g.releaseWobble||!Eligible(h)||!EffectsAllowed(h))return;
    ResetWobble(true); RECT r{}; if(!GetWindowRect(h,&r))return;
    wob.hwnd=h; wob.finalRect=wob.lastRect=r; wob.moving=true; wob.haveLast=true; wob.lastTick=GetTickCount64();
}
static void TrackMove(HWND h){
    if(!g.releaseWobble||h!=wob.hwnd||!wob.moving)return;
    RECT r{}; if(!GetWindowRect(h,&r))return; ULONGLONG now=GetTickCount64();
    double dt=(double)std::max<ULONGLONG>(1,now-wob.lastTick); double dx=r.left-wob.lastRect.left, dy=r.top-wob.lastRect.top;
    double ix=dx*(16.0/dt), iy=dy*(16.0/dt); wob.dragVX=wob.dragVX*.66+ix*.34; wob.dragVY=wob.dragVY*.66+iy*.34;
    wob.dragVX=std::clamp(wob.dragVX,-42.0,42.0); wob.dragVY=std::clamp(wob.dragVY,-42.0,42.0);
    wob.lastRect=wob.finalRect=r; wob.lastTick=now;
}
static void StartWobble(HWND h,bool forced=false){
    if(!g.releaseWobble||!Eligible(h)||!EffectsAllowed(h)){ResetWobble(false);return;}
    RECT r{}; if(!GetWindowRect(h,&r)){ResetWobble(false);return;}
    wob.hwnd=h; wob.finalRect=r; wob.moving=false; wob.animating=true; wob.startTick=GetTickCount64(); wob.ox=wob.oy=0;
    double p=.18+(g.strength/100.0)*.52; double x=wob.dragVX*p,y=wob.dragVY*p;
    if(forced||(std::abs(x)<1.0&&std::abs(y)<1.0)){x=8.5*p;y=-3.0*p;}
    wob.vx=std::clamp(x,-20.0,20.0); wob.vy=std::clamp(y,-20.0,20.0);
}
static void EndMove(HWND h){ if(h==wob.hwnd&&wob.moving){TrackMove(h);StartWobble(h);} }
static void WobbleTick(){
    if(!wob.animating||!wob.hwnd||!IsWindow(wob.hwnd)){return;}
    ULONGLONG elapsed=GetTickCount64()-wob.startTick; ULONGLONG maxMs=(ULONGLONG)(130+g.duration*5.0);
    double spring=.17+.22*(g.bounce/100.0); double damping=.70+.20*(g.settle/100.0);
    wob.vx+=(-wob.ox)*spring; wob.vy+=(-wob.oy)*spring; wob.vx*=damping; wob.vy*=damping; wob.ox+=wob.vx; wob.oy+=wob.vy;
    bool done=elapsed>=maxMs||(elapsed>100&&fabs(wob.ox)<.2&&fabs(wob.oy)<.2&&fabs(wob.vx)<.2&&fabs(wob.vy)<.2);
    if(done){ResetWobble(true);return;}
    SetWindowPos(wob.hwnd,nullptr,wob.finalRect.left+(int)lround(wob.ox),wob.finalRect.top+(int)lround(wob.oy),0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
}

static POINT TaskbarOriginFor(HWND h,const RECT& finalR){
    HMONITOR m=MonitorFromWindow(h,MONITOR_DEFAULTTONEAREST); MONITORINFO mi{sizeof(mi)}; GetMonitorInfoW(m,&mi);
    RECT wa=mi.rcWork, mon=mi.rcMonitor; POINT p{finalR.left,finalR.top};
    int dist=40+(int)(g.liftDistance*.9);
    if(wa.bottom<mon.bottom) p.y=std::min(mon.bottom-40,finalR.top+dist);
    else if(wa.top>mon.top) p.y=std::max(mon.top-finalR.bottom+finalR.top+40,finalR.top-dist);
    else if(wa.left>mon.left) p.x=std::max(mon.left+40,finalR.left-dist);
    else if(wa.right<mon.right) p.x=std::min(mon.right-40,finalR.left+dist);
    else p.y=finalR.top+dist;
    return p;
}
static void StartLift(HWND h){
    if(!g.taskbarLift||!Eligible(h)||!EffectsAllowed(h)||lift.active)return;
    RECT r{}; if(!GetWindowRect(h,&r))return;
    POINT start=TaskbarOriginFor(h,r); lift={}; lift.hwnd=h; lift.finalRect=r; lift.x=start.x; lift.y=start.y; lift.startTick=GetTickCount64(); lift.active=true;
    SetWindowPos(h,nullptr,(int)lift.x,(int)lift.y,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
}
static void LiftTick(){
    if(!lift.active)return; if(!lift.hwnd||!IsWindow(lift.hwnd)||IsIconic(lift.hwnd)){lift={};return;}
    double speed=.08+.16*(g.liftSpeed/100.0); double damp=.69+.16*(g.liftSpeed/100.0);
    lift.vx+=(lift.finalRect.left-lift.x)*speed; lift.vy+=(lift.finalRect.top-lift.y)*speed; lift.vx*=damp; lift.vy*=damp; lift.x+=lift.vx; lift.y+=lift.vy;
    ULONGLONG e=GetTickCount64()-lift.startTick; bool done=e>550||(e>110&&fabs(lift.x-lift.finalRect.left)<.35&&fabs(lift.y-lift.finalRect.top)<.35&&fabs(lift.vx)<.35&&fabs(lift.vy)<.35);
    if(done){SetWindowPos(lift.hwnd,nullptr,lift.finalRect.left,lift.finalRect.top,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSENDCHANGING);lift={};return;}
    SetWindowPos(lift.hwnd,nullptr,(int)lround(lift.x),(int)lround(lift.y),0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
}
static void AnimatedMinimize(HWND h){
    if(!Eligible(h)||!EffectsAllowed(h))return; RECT r{};if(!GetWindowRect(h,&r))return; POINT target=TaskbarOriginFor(h,r);
    for(int i=1;i<=10;i++){ double t=i/10.0; double e=t*t*(3-2*t); int x=(int)lround(r.left+(target.x-r.left)*e); int y=(int)lround(r.top+(target.y-r.top)*e); SetWindowPos(h,nullptr,x,y,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSENDCHANGING); Sleep(9); }
    SetWindowPos(h,nullptr,r.left,r.top,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSENDCHANGING); ShowWindow(h,SW_MINIMIZE);
}

static void ApplyStyles(HWND h){
    if(!Eligible(h))return;
    DWM_WINDOW_CORNER_PREFERENCE cp=g.roundedCorners?DWMWCP_ROUND:DWMWCP_DEFAULT; DwmSetWindowAttribute(h,DWMWA_WINDOW_CORNER_PREFERENCE,&cp,sizeof(cp));
    COLORREF c=g.accentBorder?RGB(119,0,255):0xFFFFFFFF; DwmSetWindowAttribute(h,DWMWA_BORDER_COLOR,&c,sizeof(c));
}
static BOOL CALLBACK EnumStyle(HWND h,LPARAM){ApplyStyles(h);return TRUE;}
static void SetStartup(bool on){
    HKEY k{}; if(RegOpenKeyExW(HKEY_CURRENT_USER,L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",0,KEY_SET_VALUE,&k)!=ERROR_SUCCESS)return;
    if(on){ wchar_t path[MAX_PATH]{}; GetModuleFileNameW(nullptr,path,MAX_PATH); RegSetValueExW(k,L"GranuleEffects",0,REG_SZ,(BYTE*)path,(DWORD)((wcslen(path)+1)*sizeof(wchar_t))); }
    else RegDeleteValueW(k,L"GranuleEffects"); RegCloseKey(k);
}
static void ToggleTop(HWND h){ if(!h||h==mainWnd||!IsWindow(h))return; bool top=(GetWindowLongPtrW(h,GWL_EXSTYLE)&WS_EX_TOPMOST)!=0; SetWindowPos(h,top?HWND_NOTOPMOST:HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE); }
static void Center(HWND h){ if(!Eligible(h))return; RECT r{};GetWindowRect(h,&r);HMONITOR m=MonitorFromWindow(h,MONITOR_DEFAULTTONEAREST);MONITORINFO mi{sizeof(mi)};GetMonitorInfoW(m,&mi);int w=r.right-r.left,hh=r.bottom-r.top;int x=mi.rcWork.left+((mi.rcWork.right-mi.rcWork.left)-w)/2,y=mi.rcWork.top+((mi.rcWork.bottom-mi.rcWork.top)-hh)/2;SetWindowPos(h,nullptr,x,y,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE); }

static void CALLBACK EventProc(HWINEVENTHOOK,DWORD e,HWND h,LONG obj,LONG,DWORD,DWORD){
    if(quitting.load()||obj!=OBJID_WINDOW||!h)return;
    if(e==EVENT_SYSTEM_MOVESIZESTART)BeginMove(h); else if(e==EVENT_SYSTEM_MOVESIZEEND)EndMove(h); else if(e==EVENT_OBJECT_LOCATIONCHANGE)TrackMove(h); else if(e==EVENT_OBJECT_SHOW){ApplyStyles(h); if(g.launchFloat) StartLift(h);} }

static BOOL CALLBACK ScanEnum(HWND h,LPARAM){
    if(h==mainWnd||!IsWindow(h))return TRUE; bool vis=IsWindowVisible(h)!=FALSE, ico=IsIconic(h)!=FALSE; auto it=seen.find(h);
    if(it==seen.end()){seen[h]={ico,vis};return TRUE;}
    if(it->second.iconic && !ico && vis && g.taskbarLift && Eligible(h)) StartLift(h);
    it->second.iconic=ico; it->second.visible=vis; return TRUE;
}
static void Scan(){ EnumWindows(ScanEnum,0); }

static Font F(float size,FontStyle style=FontStyleRegular){ static FontFamily fam(L"Segoe UI Variable Display"); static FontFamily fallback(L"Segoe UI"); if(fam.GetLastStatus()==Ok)return Font(&fam,size,style,UnitPixel); return Font(&fallback,size,style,UnitPixel); }
static void RR(Graphics&gr,const RectF2&r,float rad,const Color&fill,const Color*stroke=nullptr,float sw=1){ GraphicsPath p; float d=rad*2; p.AddArc(r.x,r.y,d,d,180,90);p.AddArc(r.x+r.w-d,r.y,d,d,270,90);p.AddArc(r.x+r.w-d,r.y+r.h-d,d,d,0,90);p.AddArc(r.x,r.y+r.h-d,d,d,90,90);p.CloseFigure(); SolidBrush b(fill);gr.FillPath(&b,&p);if(stroke){Pen pen(*stroke,sw);gr.DrawPath(&pen,&p);} }
static void Txt(Graphics&gr,const wchar_t*t,float x,float y,float size,const Color&c,bool bold=false,float width=500){ Font f=F(size,bold?FontStyleBold:FontStyleRegular);SolidBrush b(c);RectF box(x,y,width,size+10);StringFormat sf;sf.SetTrimming(StringTrimmingEllipsisCharacter);gr.DrawString(t,-1,&f,box,&sf,&b); }
static void Pill(Graphics&gr,const wchar_t*t,float x,float y,float w,bool active=true){ Color fill=active?Color(42,76,221,151):Color(255,40,41,52);Color tx=active?GREEN:MUTED;RR(gr,{x,y,w,28},14,fill,nullptr);Txt(gr,t,x+12,y+5,13,tx,true,w-20); }
static void Toggle(Graphics&gr,int id,float x,float y,bool on){ RectF2 r{x,y,48,26}; Color c=on?PURPLE:Color(255,53,55,68);RR(gr,r,13,c);float cx=on?x+35:x+13;SolidBrush b(Color::White);gr.FillEllipse(&b,cx-9,y+4,18,18);if(r.hit(ui.mouseX,ui.mouseY)){Pen p(Color(100,255,255,255),1);gr.DrawEllipse(&p,cx-10,y+3,20,20);} }
static void Slider(Graphics&gr,int id,float x,float y,float w,int val){ SolidBrush rail(Color(255,52,54,67));gr.FillRectangle(&rail,x,y+9,w,4);float px=x+w*(val/100.f);SolidBrush acc(PURPLE);gr.FillRectangle(&acc,x,y+9,px-x,4);SolidBrush knob(Color::White);gr.FillEllipse(&knob,px-7,y+4,14,14); if(id==ui.draggingSlider){Pen p(PURPLE2,2);gr.DrawEllipse(&p,px-10,y+1,20,20);} }
static void Card(Graphics&gr,float x,float y,float w,float h,const wchar_t*title,const wchar_t*sub){RR(gr,{x,y,w,h},18,CARD,&BORDER,1);Txt(gr,title,x+18,y+16,17,TEXT,true,w-36);Txt(gr,sub,x+18,y+41,13,MUTED,false,w-36);}
static void ButtonG(Graphics&gr,int id,float x,float y,float w,const wchar_t*t,bool accent=false){ bool hov=RectF2{x,y,w,38}.hit(ui.mouseX,ui.mouseY);Color fill=accent?PURPLE:(hov?Color(255,42,43,55):CARD2);RR(gr,{x,y,w,38},11,fill,&BORDER,1);Txt(gr,t,x+15,y+9,14,TEXT,true,w-30);}
static void Nav(Graphics&gr,int id,float y,const wchar_t*t,const wchar_t*glyph){ bool sel=ui.page==id;RectF2 r{16,y,194,42};if(sel)RR(gr,r,12,Color(255,33,27,48));else if(r.hit(ui.mouseX,ui.mouseY))RR(gr,r,12,Color(255,25,26,34));Txt(gr,glyph,30,y+10,16,sel?PURPLE2:MUTED,true,22);Txt(gr,t,58,y+10,15,sel?TEXT:MUTED,sel,130); }

static void PaintMotion(Graphics&gr){
    Txt(gr,L"Motion",246,70,30,TEXT,true);Txt(gr,L"Make Windows movement feel physical instead of robotic.",246,108,14,MUTED,false,700);
    Card(gr,246,148,494,164,L"Release wobble",L"Normal 1:1 dragging. The spring only kicks in after you let go.");Toggle(gr,101,670,166,g.releaseWobble);
    Txt(gr,L"Strength",264,210,13,MUTED);Slider(gr,201,352,207,260,g.strength);Txt(gr,std::to_wstring(g.strength).c_str(),624,205,13,TEXT,true,34);
    Txt(gr,L"Bounce",264,242,13,MUTED);Slider(gr,202,352,239,260,g.bounce);Txt(gr,std::to_wstring(g.bounce).c_str(),624,237,13,TEXT,true,34);
    Txt(gr,L"Settle",264,274,13,MUTED);Slider(gr,203,352,271,260,g.settle);Txt(gr,std::to_wstring(g.settle).c_str(),624,269,13,TEXT,true,34);
    Card(gr,758,148,282,164,L"Live preview",L"This mini window uses the same spring profile.");
    float dx=sinf(ui.previewPhase)*10.f*expf(-fmodf(ui.previewPhase,6.28f)*.15f);RR(gr,{802+dx,222,194,56},12,Color(255,39,41,52),&PURPLE,1);Txt(gr,L"GRANULE WINDOW",820+dx,239,12,TEXT,true,150);
    Card(gr,246,330,794,210,L"Taskbar motion",L"Linux-style lift for newly opened and restored windows.");Toggle(gr,102,970,348,g.taskbarLift);
    Txt(gr,L"Taskbar lift",264,386,15,TEXT,true);Txt(gr,L"Restored apps rise from the taskbar side with a small overshoot.",264,411,13,MUTED,false,640);
    Toggle(gr,103,970,390,g.launchFloat);Txt(gr,L"Animate newly opened windows too",264,449,15,TEXT,true);Txt(gr,L"New windows float in instead of appearing instantly.",264,474,13,MUTED,false,600);
    Txt(gr,L"Lift speed",264,510,13,MUTED);Slider(gr,204,352,507,280,g.liftSpeed);Txt(gr,std::to_wstring(g.liftSpeed).c_str(),644,505,13,TEXT,true,34);
    Txt(gr,L"Distance",708,510,13,MUTED);Slider(gr,205,786,507,170,g.liftDistance);
    ButtonG(gr,301,246,566,180,L"Test wobble",true);ButtonG(gr,302,438,566,190,L"Animated minimize");ButtonG(gr,303,640,566,170,L"Center active");
}
static void PaintWindow(Graphics&gr){
    Txt(gr,L"Window",246,70,30,TEXT,true);Txt(gr,L"Small window tweaks that feel native, not hacked together.",246,108,14,MUTED,false,700);
    Card(gr,246,148,794,120,L"Shape & border",L"DWM-powered appearance tweaks for normal desktop windows.");
    Txt(gr,L"Rounded corners",264,210,15,TEXT,true);Toggle(gr,111,470,205,g.roundedCorners);Txt(gr,L"Granule accent border",560,210,15,TEXT,true);Toggle(gr,112,772,205,g.accentBorder);
    Card(gr,246,286,386,160,L"Smart fullscreen",L"Stops motion effects in fullscreen apps and games.");Toggle(gr,113,558,306,g.pauseFullscreen);Pill(gr,g.pauseFullscreen?L"RECOMMENDED":L"OFF",264,386,112,g.pauseFullscreen);
    Card(gr,650,286,390,160,L"Quick window actions",L"Useful Windhawk-style controls without permanently patching apps.");ButtonG(gr,304,668,354,162,L"Toggle topmost");ButtonG(gr,305,842,354,180,L"Center window");
    Card(gr,246,466,794,125,L"Animated minimize",L"Ctrl+Alt+M sends the active window toward the taskbar, then minimizes it. Native title-bar minimize buttons still use Windows' own animation.");
    Pill(gr,L"CTRL + ALT + M",264,536,142,true);
}
static void PaintSystem(Graphics&gr){
    Txt(gr,L"System",246,70,30,TEXT,true);Txt(gr,L"Keep Granule lightweight and predictable.",246,108,14,MUTED,false,700);
    Card(gr,246,148,794,124,L"Startup",L"Launch Granule Effects when you sign in to Windows.");Toggle(gr,121,970,168,g.startWithWindows);
    Card(gr,246,290,794,170,L"Safety",L"Closing the X always exits completely and restores any temporary window style changes.");Pill(gr,L"NO HIDDEN PROCESS",264,368,160,true);Pill(gr,L"SETTINGS SAVED",436,368,146,true);
    Card(gr,246,478,794,112,L"Performance",L"The motion engine is event-driven and only runs an 8 ms timer while Granule is open. Fullscreen pause is recommended for games.");
}
static void PaintAbout(Graphics&gr){
    Txt(gr,L"About",246,70,30,TEXT,true);Txt(gr,L"Granule Effects v0.3",246,108,14,MUTED,false,700);
    Card(gr,246,148,794,180,L"Human motion, not random shaking",L"Release wobble reacts to how fast you moved the window. Taskbar lift uses spring motion and overshoot so it feels intentional instead of like a preset animation.");
    Txt(gr,L"Shortcuts",264,270,15,TEXT,true);Txt(gr,L"Ctrl+Alt+G  pause/resume     Ctrl+Alt+W  test wobble     Ctrl+Alt+T  topmost     Ctrl+Alt+C  center     Ctrl+Alt+M  animated minimize",264,301,13,MUTED,false,740);
    Card(gr,246,352,794,170,L"What v0.3 does not fake",L"It moves real Windows windows. It does not yet bend/deform the pixels like Compiz's true mesh wobble. That would need a GPU capture + shader layer.");
}
static void Paint(HWND h,HDC dc){
    RECT rc{};GetClientRect(h,&rc); Graphics gr(dc);gr.SetSmoothingMode(SmoothingModeAntiAlias);SolidBrush bg(BG);gr.FillRectangle(&bg,0,0,rc.right,rc.bottom);SolidBrush sb(SIDEBAR);gr.FillRectangle(&sb,0,0,226,rc.bottom);
    RR(gr,{16,18,194,52},16,Color(255,26,22,38));SolidBrush dot(PURPLE);gr.FillEllipse(&dot,28,32,24,24);Txt(gr,L"G",35,34,13,Color::White,true,20);Txt(gr,L"GRANULE",62,28,16,TEXT,true,120);Txt(gr,L"Effects v0.3",62,48,11,MUTED,false,120);
    Nav(gr,0,92,L"Motion",L"M");Nav(gr,1,140,L"Window",L"W");Nav(gr,2,188,L"System",L"S");Nav(gr,3,236,L"About",L"i");
    Txt(gr,L"ENGINE",28,314,11,MUTED,true,100);Pill(gr,L"ACTIVE",28,336,84,true);Txt(gr,L"release-only wobble",28,374,12,MUTED,false,160);
    RR(gr,{24,560,178,70},14,Color(255,22,23,30),&BORDER,1);Txt(gr,L"X exits completely",38,575,13,TEXT,true,150);Txt(gr,L"No tray ghost process",38,598,11,MUTED,false,150);
    if(ui.page==0)PaintMotion(gr);else if(ui.page==1)PaintWindow(gr);else if(ui.page==2)PaintSystem(gr);else PaintAbout(gr);
    // custom title controls
    ButtonG(gr,901,982,18,28,L"—");ButtonG(gr,902,1020,18,28,L"×");
}

static void ChangeSlider(int id,int mx){
    int x=352,w=260,*v=nullptr; if(id==201)v=&g.strength;else if(id==202)v=&g.bounce;else if(id==203)v=&g.settle;else if(id==204){v=&g.liftSpeed;w=280;}else if(id==205){v=&g.liftDistance;x=786;w=170;} if(!v)return;
    *v=std::clamp((int)lround((mx-x)*100.0/w),0,100); Save();InvalidateRect(mainWnd,nullptr,FALSE);
}
static int HitControl(int x,int y){
    if(x<226){ if(RectF2{16,92,194,42}.hit(x,y))return 10;if(RectF2{16,140,194,42}.hit(x,y))return 11;if(RectF2{16,188,194,42}.hit(x,y))return 12;if(RectF2{16,236,194,42}.hit(x,y))return 13; }
    if(RectF2{982,18,28,38}.hit(x,y))return 901;if(RectF2{1020,18,28,38}.hit(x,y))return 902;
    if(ui.page==0){ if(RectF2{670,166,48,26}.hit(x,y))return 101;if(RectF2{970,348,48,26}.hit(x,y))return 102;if(RectF2{970,390,48,26}.hit(x,y))return 103;
        if(RectF2{352,207,260,24}.hit(x,y))return 201;if(RectF2{352,239,260,24}.hit(x,y))return 202;if(RectF2{352,271,260,24}.hit(x,y))return 203;if(RectF2{352,507,280,24}.hit(x,y))return 204;if(RectF2{786,507,170,24}.hit(x,y))return 205;
        if(RectF2{246,566,180,38}.hit(x,y))return 301;if(RectF2{438,566,190,38}.hit(x,y))return 302;if(RectF2{640,566,170,38}.hit(x,y))return 303; }
    if(ui.page==1){ if(RectF2{470,205,48,26}.hit(x,y))return 111;if(RectF2{772,205,48,26}.hit(x,y))return 112;if(RectF2{558,306,48,26}.hit(x,y))return 113;if(RectF2{668,354,162,38}.hit(x,y))return 304;if(RectF2{842,354,180,38}.hit(x,y))return 305; }
    if(ui.page==2 && RectF2{970,168,48,26}.hit(x,y))return 121; return 0;
}
static void Activate(int id){
    if(id>=10&&id<=13){ui.page=id-10;InvalidateRect(mainWnd,nullptr,FALSE);return;}
    if(id==901){ShowWindow(mainWnd,SW_MINIMIZE);return;} if(id==902){DestroyWindow(mainWnd);return;}
    if(id==101)g.releaseWobble=!g.releaseWobble; else if(id==102)g.taskbarLift=!g.taskbarLift; else if(id==103)g.launchFloat=!g.launchFloat;
    else if(id==111){g.roundedCorners=!g.roundedCorners;EnumWindows(EnumStyle,0);} else if(id==112){g.accentBorder=!g.accentBorder;EnumWindows(EnumStyle,0);} else if(id==113)g.pauseFullscreen=!g.pauseFullscreen;
    else if(id==121){g.startWithWindows=!g.startWithWindows;SetStartup(g.startWithWindows);} else if(id==301){wob.dragVX=18;wob.dragVY=-5;StartWobble(mainWnd,true);} else if(id==302){HWND h=GetForegroundWindow();if(h==mainWnd)h=GetWindow(mainWnd,GW_HWNDNEXT);AnimatedMinimize(h);} else if(id==303)Center(GetForegroundWindow()); else if(id==304)ToggleTop(GetForegroundWindow()); else if(id==305)Center(GetForegroundWindow());
    Save();InvalidateRect(mainWnd,nullptr,FALSE);
}

static LRESULT CALLBACK WndProc(HWND h,UINT m,WPARAM w,LPARAM l){
    switch(m){
    case WM_CREATE:{
        BOOL dark=TRUE;DwmSetWindowAttribute(h,DWMWA_USE_IMMERSIVE_DARK_MODE,&dark,sizeof(dark));DWM_WINDOW_CORNER_PREFERENCE cp=DWMWCP_ROUND;DwmSetWindowAttribute(h,DWMWA_WINDOW_CORNER_PREFERENCE,&cp,sizeof(cp));
        SetTimer(h,TICK,8,nullptr);SetTimer(h,SCAN,90,nullptr);return 0;}
    case WM_NCHITTEST:{LRESULT r=DefWindowProcW(h,m,w,l);POINT p{GET_X_LPARAM(l),GET_Y_LPARAM(l)};ScreenToClient(h,&p);if(p.y<60&&p.x>226&&p.x<970)return HTCAPTION;return r;}
    case WM_MOUSEMOVE:{ui.mouseX=GET_X_LPARAM(l);ui.mouseY=GET_Y_LPARAM(l);if(ui.draggingSlider)ChangeSlider(ui.draggingSlider,ui.mouseX);InvalidateRect(h,nullptr,FALSE);return 0;}
    case WM_LBUTTONDOWN:{SetCapture(h);int id=HitControl(GET_X_LPARAM(l),GET_Y_LPARAM(l));ui.down=id;if(id>=201&&id<=205){ui.draggingSlider=id;ChangeSlider(id,GET_X_LPARAM(l));}return 0;}
    case WM_LBUTTONUP:{ReleaseCapture();int id=HitControl(GET_X_LPARAM(l),GET_Y_LPARAM(l));if(ui.down==id&&id&&!ui.draggingSlider)Activate(id);ui.down=0;ui.draggingSlider=0;return 0;}
    case WM_HOTKEY:{if(w==1){g.releaseWobble=!g.releaseWobble;Save();InvalidateRect(h,nullptr,FALSE);}else if(w==2)ToggleTop(GetForegroundWindow());else if(w==3)Center(GetForegroundWindow());else if(w==4){HWND f=GetForegroundWindow();wob.dragVX=16;wob.dragVY=-4;StartWobble(f,true);}else if(w==5)AnimatedMinimize(GetForegroundWindow());return 0;}
    case WM_TIMER:{if(w==TICK){WobbleTick();LiftTick();ui.previewPhase+=.045f;InvalidateRect(h,nullptr,FALSE);}else if(w==SCAN){Scan();if(g.roundedCorners||g.accentBorder)EnumWindows(EnumStyle,0);}return 0;}
    case WM_PAINT:{PAINTSTRUCT ps{};HDC dc=BeginPaint(h,&ps);Paint(h,dc);EndPaint(h,&ps);return 0;}
    case WM_ERASEBKGND:return 1;
    case WM_CLOSE:DestroyWindow(h);return 0;
    case WM_DESTROY:{quitting.store(true);ResetWobble(true);if(lift.active&&lift.hwnd&&IsWindow(lift.hwnd))SetWindowPos(lift.hwnd,nullptr,lift.finalRect.left,lift.finalRect.top,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);lift={};
        Settings old=g;g.roundedCorners=false;g.accentBorder=false;EnumWindows(EnumStyle,0);g=old;Save();
        if(hookStart)UnhookWinEvent(hookStart);if(hookEnd)UnhookWinEvent(hookEnd);if(hookLoc)UnhookWinEvent(hookLoc);if(hookShow)UnhookWinEvent(hookShow);
        for(int i=1;i<=5;i++)UnregisterHotKey(h,i);KillTimer(h,TICK);KillTimer(h,SCAN);PostQuitMessage(0);return 0;}
    }
    return DefWindowProcW(h,m,w,l);
}

int WINAPI wWinMain(HINSTANCE hi,HINSTANCE,PWSTR,int show){
    Load(); GdiplusStartupInput gi;GdiplusStartup(&gdipToken,&gi,nullptr);
    WNDCLASSEXW wc{sizeof(wc)};wc.lpfnWndProc=WndProc;wc.hInstance=hi;wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);wc.hIcon=LoadIconW(nullptr,IDI_APPLICATION);wc.lpszClassName=CLS;wc.style=CS_DBLCLKS;RegisterClassExW(&wc);
    mainWnd=CreateWindowExW(0,CLS,L"Granule Effects v0.3",WS_POPUP|WS_THICKFRAME|WS_MINIMIZEBOX|WS_SYSMENU,CW_USEDEFAULT,CW_USEDEFAULT,1080,680,nullptr,nullptr,hi,nullptr);if(!mainWnd)return 2;
    const DWORD f=WINEVENT_OUTOFCONTEXT|WINEVENT_SKIPOWNPROCESS;hookStart=SetWinEventHook(EVENT_SYSTEM_MOVESIZESTART,EVENT_SYSTEM_MOVESIZESTART,nullptr,EventProc,0,0,f);hookEnd=SetWinEventHook(EVENT_SYSTEM_MOVESIZEEND,EVENT_SYSTEM_MOVESIZEEND,nullptr,EventProc,0,0,f);hookLoc=SetWinEventHook(EVENT_OBJECT_LOCATIONCHANGE,EVENT_OBJECT_LOCATIONCHANGE,nullptr,EventProc,0,0,f);hookShow=SetWinEventHook(EVENT_OBJECT_SHOW,EVENT_OBJECT_SHOW,nullptr,EventProc,0,0,f);
    RegisterHotKey(mainWnd,1,MOD_CONTROL|MOD_ALT,'G');RegisterHotKey(mainWnd,2,MOD_CONTROL|MOD_ALT,'T');RegisterHotKey(mainWnd,3,MOD_CONTROL|MOD_ALT,'C');RegisterHotKey(mainWnd,4,MOD_CONTROL|MOD_ALT,'W');RegisterHotKey(mainWnd,5,MOD_CONTROL|MOD_ALT,'M');
    ShowWindow(mainWnd,show);UpdateWindow(mainWnd);EnumWindows(EnumStyle,0);Scan();MSG msg{};while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}GdiplusShutdown(gdipToken);return (int)msg.wParam;
}
