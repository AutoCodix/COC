#define UNICODE
#define _UNICODE
#include <windows.h>
#include <shellapi.h>
#include <commctrl.h>
#include <dwmapi.h>
#include <string>
#include <cmath>
#include <atomic>
#include <algorithm>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "dwmapi.lib")

#ifndef DWMWA_WINDOW_CORNER_PREFERENCE
#define DWMWA_WINDOW_CORNER_PREFERENCE 33
#endif
#ifndef DWMWCP_DEFAULT
enum DWM_WINDOW_CORNER_PREFERENCE {
    DWMWCP_DEFAULT = 0,
    DWMWCP_DONOTROUND = 1,
    DWMWCP_ROUND = 2,
    DWMWCP_ROUNDSMALL = 3
};
#endif
#ifndef DWMWA_BORDER_COLOR
#define DWMWA_BORDER_COLOR 34
#endif

static constexpr UINT WM_TRAY = WM_APP + 1;
static constexpr UINT TIMER_TICK = 1;
static constexpr UINT TIMER_SCAN = 2;
static constexpr int HOTKEY_TOGGLE = 1;
static constexpr int HOTKEY_TOPMOST = 2;
static constexpr int HOTKEY_CENTER = 3;
static constexpr int HOTKEY_TEST = 4;
static const wchar_t* kClassName = L"GranuleEffectsWindowV02";

struct Settings {
    bool enabled = true;
    bool roundedCorners = false;
    bool accentBorder = false;
    int strength = 45; // impulse size
    int bounce = 58;   // oscillation amount
    int settle = 62;   // damping
    int duration = 34; // 120-650 ms mapping
};

struct WobbleState {
    HWND target = nullptr;
    RECT finalRect{};
    RECT lastRect{};
    bool moving = false;
    bool animating = false;
    bool haveLast = false;
    double vx = 0.0, vy = 0.0;
    double ox = 0.0, oy = 0.0;
    double dragVX = 0.0, dragVY = 0.0;
    ULONGLONG lastMoveTick = 0;
    ULONGLONG animStart = 0;
};

static Settings g_settings;
static WobbleState g_state;
static HWND g_main = nullptr;
static HWINEVENTHOOK g_hookStart = nullptr;
static HWINEVENTHOOK g_hookEnd = nullptr;
static HWINEVENTHOOK g_hookLoc = nullptr;
static HWINEVENTHOOK g_hookShow = nullptr;
static std::atomic<bool> g_quitting{false};
static NOTIFYICONDATAW g_nid{};
static HBRUSH g_bgBrush = nullptr;
static HBRUSH g_panelBrush = nullptr;
static HFONT g_font = nullptr;
static HFONT g_fontBold = nullptr;

static bool IsShellClass(const wchar_t* cls) {
    return wcscmp(cls, L"Progman") == 0 || wcscmp(cls, L"WorkerW") == 0 ||
           wcscmp(cls, L"Shell_TrayWnd") == 0 || wcscmp(cls, L"Shell_SecondaryTrayWnd") == 0;
}

static bool IsEligibleWindow(HWND hwnd) {
    if (!hwnd || hwnd == g_main || !IsWindow(hwnd) || !IsWindowVisible(hwnd)) return false;
    if (GetWindow(hwnd, GW_OWNER) != nullptr) return false;
    LONG_PTR style = GetWindowLongPtrW(hwnd, GWL_STYLE);
    if (!(style & WS_CAPTION)) return false;
    if (IsZoomed(hwnd) || IsIconic(hwnd)) return false;
    wchar_t cls[128]{};
    GetClassNameW(hwnd, cls, 127);
    if (IsShellClass(cls)) return false;
    return true;
}

static void RestoreTarget() {
    if (g_state.target && IsWindow(g_state.target) && g_state.animating) {
        SetWindowPos(g_state.target, nullptr, g_state.finalRect.left, g_state.finalRect.top, 0, 0,
                     SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_NOSENDCHANGING);
    }
}

static void ResetState(bool restore = false) {
    if (restore) RestoreTarget();
    g_state = {};
}

static void BeginMove(HWND hwnd) {
    if (!g_settings.enabled || !IsEligibleWindow(hwnd)) return;
    ResetState(true);
    RECT r{};
    if (!GetWindowRect(hwnd, &r)) return;
    g_state.target = hwnd;
    g_state.lastRect = r;
    g_state.finalRect = r;
    g_state.haveLast = true;
    g_state.moving = true;
    g_state.lastMoveTick = GetTickCount64();
}

static void TrackMove(HWND hwnd) {
    if (!g_settings.enabled || hwnd != g_state.target || !g_state.moving) return;
    RECT r{};
    if (!GetWindowRect(hwnd, &r)) return;
    ULONGLONG now = GetTickCount64();
    if (!g_state.haveLast) {
        g_state.lastRect = r;
        g_state.haveLast = true;
        g_state.lastMoveTick = now;
        return;
    }

    const double dt = std::max<double>(1.0, static_cast<double>(now - g_state.lastMoveTick));
    const double dx = static_cast<double>(r.left - g_state.lastRect.left);
    const double dy = static_cast<double>(r.top - g_state.lastRect.top);
    const double instVX = dx * (16.0 / dt);
    const double instVY = dy * (16.0 / dt);

    // Low-pass velocity: follows the final flick but ignores single noisy jumps.
    g_state.dragVX = g_state.dragVX * 0.62 + instVX * 0.38;
    g_state.dragVY = g_state.dragVY * 0.62 + instVY * 0.38;
    g_state.dragVX = std::clamp(g_state.dragVX, -40.0, 40.0);
    g_state.dragVY = std::clamp(g_state.dragVY, -40.0, 40.0);
    g_state.lastRect = r;
    g_state.finalRect = r;
    g_state.lastMoveTick = now;
}

static void StartReleaseWobble(HWND hwnd, bool forced = false) {
    if (!g_settings.enabled || !IsEligibleWindow(hwnd)) {
        ResetState();
        return;
    }
    RECT r{};
    if (!GetWindowRect(hwnd, &r)) {
        ResetState();
        return;
    }
    g_state.target = hwnd;
    g_state.finalRect = r;
    g_state.lastRect = r;
    g_state.moving = false;
    g_state.animating = true;
    g_state.animStart = GetTickCount64();
    g_state.ox = 0.0;
    g_state.oy = 0.0;

    const double power = 0.18 + (g_settings.strength / 100.0) * 0.52;
    double ix = g_state.dragVX * power;
    double iy = g_state.dragVY * power;
    if (forced || (std::abs(ix) < 1.1 && std::abs(iy) < 1.1)) {
        ix = 9.0 * power;
        iy = -3.0 * power;
    }
    g_state.vx = std::clamp(ix, -20.0, 20.0);
    g_state.vy = std::clamp(iy, -20.0, 20.0);
}

static void EndMove(HWND hwnd) {
    if (hwnd != g_state.target || !g_state.moving) return;
    TrackMove(hwnd);
    StartReleaseWobble(hwnd, false);
}

static void ApplyWobbleTick() {
    if (!g_settings.enabled || !g_state.animating || !g_state.target || !IsWindow(g_state.target)) return;

    const ULONGLONG elapsed = GetTickCount64() - g_state.animStart;
    const ULONGLONG maxMs = static_cast<ULONGLONG>(120 + g_settings.duration * 5.3);
    const double bounce = g_settings.bounce / 100.0;
    const double settle = g_settings.settle / 100.0;
    const double spring = 0.16 + 0.22 * bounce;
    const double damping = 0.70 + 0.20 * settle;

    g_state.vx += (-g_state.ox) * spring;
    g_state.vy += (-g_state.oy) * spring;
    g_state.vx *= damping;
    g_state.vy *= damping;
    g_state.ox += g_state.vx;
    g_state.oy += g_state.vy;

    const bool finished = elapsed >= maxMs ||
        (elapsed > 100 && std::abs(g_state.ox) < 0.20 && std::abs(g_state.oy) < 0.20 &&
         std::abs(g_state.vx) < 0.20 && std::abs(g_state.vy) < 0.20);

    if (finished) {
        RestoreTarget();
        ResetState();
        return;
    }

    const int x = g_state.finalRect.left + static_cast<int>(std::lround(g_state.ox));
    const int y = g_state.finalRect.top + static_cast<int>(std::lround(g_state.oy));
    SetWindowPos(g_state.target, nullptr, x, y, 0, 0,
                 SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_NOSENDCHANGING);
}

static void ApplyStyleTweaks(HWND hwnd) {
    if (!IsEligibleWindow(hwnd)) return;
    if (g_settings.roundedCorners) {
        DWM_WINDOW_CORNER_PREFERENCE pref = DWMWCP_ROUND;
        DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, &pref, sizeof(pref));
    }
    if (g_settings.accentBorder) {
        // COLORREF: subtle Granule violet border.
        COLORREF c = RGB(119, 0, 255);
        DwmSetWindowAttribute(hwnd, DWMWA_BORDER_COLOR, &c, sizeof(c));
    }
}

static BOOL CALLBACK ApplyStyleEnum(HWND hwnd, LPARAM) {
    ApplyStyleTweaks(hwnd);
    return TRUE;
}

static BOOL CALLBACK ResetStyleEnum(HWND hwnd, LPARAM) {
    if (!IsWindow(hwnd)) return TRUE;
    DWM_WINDOW_CORNER_PREFERENCE pref = DWMWCP_DEFAULT;
    DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, &pref, sizeof(pref));
    COLORREF def = 0xFFFFFFFF; // DWMWA_COLOR_DEFAULT
    DwmSetWindowAttribute(hwnd, DWMWA_BORDER_COLOR, &def, sizeof(def));
    return TRUE;
}

static void ToggleTopmost(HWND hwnd) {
    if (!hwnd || hwnd == g_main || !IsWindow(hwnd)) return;
    LONG_PTR ex = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
    const bool isTop = (ex & WS_EX_TOPMOST) != 0;
    SetWindowPos(hwnd, isTop ? HWND_NOTOPMOST : HWND_TOPMOST, 0, 0, 0, 0,
                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

static void CenterWindow(HWND hwnd) {
    if (!IsEligibleWindow(hwnd)) return;
    RECT r{};
    if (!GetWindowRect(hwnd, &r)) return;
    HMONITOR mon = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi{sizeof(mi)};
    if (!GetMonitorInfoW(mon, &mi)) return;
    const int w = r.right - r.left;
    const int h = r.bottom - r.top;
    const int x = mi.rcWork.left + ((mi.rcWork.right - mi.rcWork.left) - w) / 2;
    const int y = mi.rcWork.top + ((mi.rcWork.bottom - mi.rcWork.top) - h) / 2;
    SetWindowPos(hwnd, nullptr, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}

static void CALLBACK WinEventProc(HWINEVENTHOOK, DWORD event, HWND hwnd, LONG idObject, LONG, DWORD, DWORD) {
    if (g_quitting.load() || idObject != OBJID_WINDOW || !hwnd) return;
    switch (event) {
        case EVENT_SYSTEM_MOVESIZESTART: BeginMove(hwnd); break;
        case EVENT_SYSTEM_MOVESIZEEND: EndMove(hwnd); break;
        case EVENT_OBJECT_LOCATIONCHANGE: TrackMove(hwnd); break;
        case EVENT_OBJECT_SHOW: ApplyStyleTweaks(hwnd); break;
    }
}

static void InstallHooks() {
    const DWORD flags = WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS;
    g_hookStart = SetWinEventHook(EVENT_SYSTEM_MOVESIZESTART, EVENT_SYSTEM_MOVESIZESTART, nullptr, WinEventProc, 0, 0, flags);
    g_hookEnd = SetWinEventHook(EVENT_SYSTEM_MOVESIZEEND, EVENT_SYSTEM_MOVESIZEEND, nullptr, WinEventProc, 0, 0, flags);
    g_hookLoc = SetWinEventHook(EVENT_OBJECT_LOCATIONCHANGE, EVENT_OBJECT_LOCATIONCHANGE, nullptr, WinEventProc, 0, 0, flags);
    g_hookShow = SetWinEventHook(EVENT_OBJECT_SHOW, EVENT_OBJECT_SHOW, nullptr, WinEventProc, 0, 0, flags);
}

static void UninstallHooks() {
    if (g_hookStart) UnhookWinEvent(g_hookStart);
    if (g_hookEnd) UnhookWinEvent(g_hookEnd);
    if (g_hookLoc) UnhookWinEvent(g_hookLoc);
    if (g_hookShow) UnhookWinEvent(g_hookShow);
    g_hookStart = g_hookEnd = g_hookLoc = g_hookShow = nullptr;
}

static void SetFont(HWND h, bool bold = false) {
    SendMessageW(h, WM_SETFONT, reinterpret_cast<WPARAM>(bold ? g_fontBold : g_font), TRUE);
}

static HWND Label(HWND p, const wchar_t* t, int x, int y, int w, int h, int id = 0, bool bold = false) {
    HWND c = CreateWindowW(L"STATIC", t, WS_CHILD | WS_VISIBLE, x, y, w, h, p,
                           id ? reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)) : nullptr, nullptr, nullptr);
    SetFont(c, bold);
    return c;
}

static HWND Check(HWND p, const wchar_t* t, int id, int x, int y, int w, bool checked) {
    HWND c = CreateWindowW(L"BUTTON", t, WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, x, y, w, 26, p,
                           reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), nullptr, nullptr);
    SetFont(c);
    SendMessageW(c, BM_SETCHECK, checked ? BST_CHECKED : BST_UNCHECKED, 0);
    return c;
}

static HWND Button(HWND p, const wchar_t* t, int id, int x, int y, int w, int h = 30) {
    HWND c = CreateWindowW(L"BUTTON", t, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, x, y, w, h, p,
                           reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), nullptr, nullptr);
    SetFont(c);
    return c;
}

static HWND Slider(HWND p, int id, int x, int y, int w, int value) {
    HWND c = CreateWindowW(TRACKBAR_CLASSW, L"", WS_CHILD | WS_VISIBLE | TBS_NOTICKS,
                           x, y, w, 30, p, reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)), nullptr, nullptr);
    SendMessageW(c, TBM_SETRANGE, TRUE, MAKELPARAM(0, 100));
    SendMessageW(c, TBM_SETPOS, TRUE, value);
    return c;
}

static void UpdateStatus() {
    HWND s = GetDlgItem(g_main, 130);
    if (s) SetWindowTextW(s, g_settings.enabled ? L"ACTIVE - release wobble is enabled" : L"PAUSED - windows are untouched");
}

static void AddTrayIcon(HWND hwnd) {
    g_nid = {};
    g_nid.cbSize = sizeof(g_nid);
    g_nid.hWnd = hwnd;
    g_nid.uID = 1;
    g_nid.uFlags = NIF_MESSAGE | NIF_TIP | NIF_ICON;
    g_nid.uCallbackMessage = WM_TRAY;
    g_nid.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    wcscpy_s(g_nid.szTip, L"Granule Effects v0.2");
    Shell_NotifyIconW(NIM_ADD, &g_nid);
}

static void ShowTrayMenu(HWND hwnd) {
    HMENU menu = CreatePopupMenu();
    AppendMenuW(menu, MF_STRING, 301, L"Open");
    AppendMenuW(menu, MF_STRING | (g_settings.enabled ? MF_CHECKED : 0), 302, L"Release wobble");
    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(menu, MF_STRING, 303, L"Exit completely");
    POINT p{}; GetCursorPos(&p);
    SetForegroundWindow(hwnd);
    TrackPopupMenu(menu, TPM_RIGHTBUTTON, p.x, p.y, 0, hwnd, nullptr);
    DestroyMenu(menu);
}

static void SetEnabled(bool enabled) {
    g_settings.enabled = enabled;
    SendMessageW(GetDlgItem(g_main, 101), BM_SETCHECK, enabled ? BST_CHECKED : BST_UNCHECKED, 0);
    if (!enabled) ResetState(true);
    UpdateStatus();
}

static void BuildUi(HWND hwnd) {
    Label(hwnd, L"Granule Effects", 22, 18, 240, 30, 0, true);
    Label(hwnd, L"Windows motion + small system tweaks. Native, global, lightweight.", 22, 49, 510, 22);
    Label(hwnd, L"MOTION", 22, 84, 120, 20, 0, true);
    Check(hwnd, L"Release wobble", 101, 22, 108, 180, true);
    Label(hwnd, L"Normal while dragging. Wobbles only after you let go.", 206, 112, 340, 20);

    Label(hwnd, L"Strength", 22, 153, 100, 20);
    Slider(hwnd, 102, 112, 145, 300, g_settings.strength);
    Label(hwnd, L"Bounce", 22, 192, 100, 20);
    Slider(hwnd, 103, 112, 184, 300, g_settings.bounce);
    Label(hwnd, L"Settle", 22, 231, 100, 20);
    Slider(hwnd, 104, 112, 223, 300, g_settings.settle);
    Label(hwnd, L"Length", 22, 270, 100, 20);
    Slider(hwnd, 105, 112, 262, 300, g_settings.duration);
    Button(hwnd, L"Test on this window", 106, 424, 227, 132, 65);

    Label(hwnd, L"WINDOW TWEAKS", 22, 316, 150, 20, 0, true);
    Check(hwnd, L"Rounded corners", 110, 22, 340, 180, false);
    Check(hwnd, L"Granule accent border", 111, 218, 340, 210, false);
    Label(hwnd, L"Applied to normal top-level windows while enabled.", 22, 369, 430, 20);

    Label(hwnd, L"QUICK ACTIONS", 22, 405, 150, 20, 0, true);
    Button(hwnd, L"Toggle topmost", 120, 22, 430, 165);
    Button(hwnd, L"Center active window", 121, 198, 430, 165);
    Button(hwnd, L"Pause / Resume", 122, 374, 430, 165);
    Label(hwnd, L"Hotkeys: Ctrl+Alt+T topmost   Ctrl+Alt+C center   Ctrl+Alt+G pause   Ctrl+Alt+W test wobble", 22, 470, 550, 34);

    Label(hwnd, L"ACTIVE - release wobble is enabled", 22, 514, 410, 22, 130, true);
    Label(hwnd, L"X exits completely. It will never stay secretly running after you close it.", 22, 542, 530, 22);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_CREATE:
            BuildUi(hwnd);
            AddTrayIcon(hwnd);
            SetTimer(hwnd, TIMER_TICK, 8, nullptr);
            SetTimer(hwnd, TIMER_SCAN, 1500, nullptr);
            return 0;
        case WM_HSCROLL: {
            HWND from = reinterpret_cast<HWND>(lp);
            const int id = GetDlgCtrlID(from);
            const int pos = static_cast<int>(SendMessageW(from, TBM_GETPOS, 0, 0));
            if (id == 102) g_settings.strength = pos;
            else if (id == 103) g_settings.bounce = pos;
            else if (id == 104) g_settings.settle = pos;
            else if (id == 105) g_settings.duration = pos;
            return 0;
        }
        case WM_COMMAND: {
            const int id = LOWORD(wp);
            if (id == 101) SetEnabled(SendMessageW(GetDlgItem(hwnd, 101), BM_GETCHECK, 0, 0) == BST_CHECKED);
            else if (id == 106) { g_state.dragVX = 18; g_state.dragVY = -5; StartReleaseWobble(hwnd, true); }
            else if (id == 110) {
                g_settings.roundedCorners = SendMessageW(GetDlgItem(hwnd, 110), BM_GETCHECK, 0, 0) == BST_CHECKED;
                if (g_settings.roundedCorners) EnumWindows(ApplyStyleEnum, 0); else EnumWindows(ResetStyleEnum, 0);
            }
            else if (id == 111) {
                g_settings.accentBorder = SendMessageW(GetDlgItem(hwnd, 111), BM_GETCHECK, 0, 0) == BST_CHECKED;
                if (g_settings.accentBorder) EnumWindows(ApplyStyleEnum, 0); else EnumWindows(ResetStyleEnum, 0);
            }
            else if (id == 120) ToggleTopmost(GetForegroundWindow());
            else if (id == 121) CenterWindow(GetForegroundWindow());
            else if (id == 122) SetEnabled(!g_settings.enabled);
            else if (id == 301) { ShowWindow(hwnd, SW_SHOW); SetForegroundWindow(hwnd); }
            else if (id == 302) SetEnabled(!g_settings.enabled);
            else if (id == 303) DestroyWindow(hwnd);
            return 0;
        }
        case WM_HOTKEY:
            if (wp == HOTKEY_TOGGLE) SetEnabled(!g_settings.enabled);
            else if (wp == HOTKEY_TOPMOST) ToggleTopmost(GetForegroundWindow());
            else if (wp == HOTKEY_CENTER) CenterWindow(GetForegroundWindow());
            else if (wp == HOTKEY_TEST) {
                HWND f = GetForegroundWindow();
                g_state.dragVX = 16; g_state.dragVY = -4; StartReleaseWobble(f, true);
            }
            return 0;
        case WM_TIMER:
            if (wp == TIMER_TICK) ApplyWobbleTick();
            else if (wp == TIMER_SCAN && (g_settings.roundedCorners || g_settings.accentBorder)) EnumWindows(ApplyStyleEnum, 0);
            return 0;
        case WM_TRAY:
            if (lp == WM_RBUTTONUP || lp == WM_CONTEXTMENU) ShowTrayMenu(hwnd);
            else if (lp == WM_LBUTTONDBLCLK) { ShowWindow(hwnd, SW_SHOW); SetForegroundWindow(hwnd); }
            return 0;
        case WM_CTLCOLORSTATIC: {
            HDC dc = reinterpret_cast<HDC>(wp);
            SetTextColor(dc, RGB(226, 226, 232));
            SetBkColor(dc, RGB(24, 24, 29));
            return reinterpret_cast<LRESULT>(g_bgBrush);
        }
        case WM_CTLCOLORBTN: {
            HDC dc = reinterpret_cast<HDC>(wp);
            SetTextColor(dc, RGB(226, 226, 232));
            SetBkColor(dc, RGB(24, 24, 29));
            return reinterpret_cast<LRESULT>(g_bgBrush);
        }
        case WM_ERASEBKGND: {
            RECT r{}; GetClientRect(hwnd, &r);
            FillRect(reinterpret_cast<HDC>(wp), &r, g_bgBrush);
            return 1;
        }
        case WM_CLOSE:
            // v0.1 hid to tray here. v0.2 exits completely by design.
            DestroyWindow(hwnd);
            return 0;
        case WM_DESTROY:
            g_quitting.store(true);
            ResetState(true);
            EnumWindows(ResetStyleEnum, 0);
            KillTimer(hwnd, TIMER_TICK);
            KillTimer(hwnd, TIMER_SCAN);
            Shell_NotifyIconW(NIM_DELETE, &g_nid);
            UninstallHooks();
            UnregisterHotKey(hwnd, HOTKEY_TOGGLE);
            UnregisterHotKey(hwnd, HOTKEY_TOPMOST);
            UnregisterHotKey(hwnd, HOTKEY_CENTER);
            UnregisterHotKey(hwnd, HOTKEY_TEST);
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, PWSTR, int nCmdShow) {
    INITCOMMONCONTROLSEX icc{sizeof(icc), ICC_BAR_CLASSES | ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&icc);

    g_bgBrush = CreateSolidBrush(RGB(24, 24, 29));
    g_panelBrush = CreateSolidBrush(RGB(31, 31, 38));
    g_font = CreateFontW(-16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                         OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                         DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
    g_fontBold = CreateFontW(-18, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                             OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                             DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");

    WNDCLASSEXW wc{sizeof(wc)};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    wc.hbrBackground = g_bgBrush;
    wc.lpszClassName = kClassName;
    if (!RegisterClassExW(&wc)) return 1;

    g_main = CreateWindowExW(0, kClassName, L"Granule Effects v0.2", WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
                             CW_USEDEFAULT, CW_USEDEFAULT, 600, 620, nullptr, nullptr, hInst, nullptr);
    if (!g_main) return 2;

    InstallHooks();
    RegisterHotKey(g_main, HOTKEY_TOGGLE, MOD_CONTROL | MOD_ALT, 'G');
    RegisterHotKey(g_main, HOTKEY_TOPMOST, MOD_CONTROL | MOD_ALT, 'T');
    RegisterHotKey(g_main, HOTKEY_CENTER, MOD_CONTROL | MOD_ALT, 'C');
    RegisterHotKey(g_main, HOTKEY_TEST, MOD_CONTROL | MOD_ALT, 'W');

    ShowWindow(g_main, nCmdShow);
    UpdateWindow(g_main);

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    DeleteObject(g_font);
    DeleteObject(g_fontBold);
    DeleteObject(g_bgBrush);
    DeleteObject(g_panelBrush);
    return static_cast<int>(msg.wParam);
}
