# Granule Effects v0.2

A lightweight native Windows customization prototype.

## Motion behavior
- Windows move normally while you hold the mouse.
- The wobble starts only after you release the window.
- Strength, bounce, settle and animation length are adjustable.
- Closing the main window exits completely and restores any active wobble.

## Extra window tweaks
- Optional rounded corners.
- Optional Granule accent border.
- Ctrl+Alt+T: toggle always-on-top for the active window.
- Ctrl+Alt+C: center the active window.
- Ctrl+Alt+G: pause/resume Granule Effects.
- Ctrl+Alt+W: test a wobble on the active window.

## Limitation
This version wobbles the window's position. It does not yet bend the live pixels into a Compiz-style mesh. True mesh deformation requires a GPU capture + shader overlay renderer and is a separate engine step.
